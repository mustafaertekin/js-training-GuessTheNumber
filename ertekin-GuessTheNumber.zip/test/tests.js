/**
 * Please use the file "js/functions.js" for your functions.
 *
 */


describe('Test Suite - Guess Game Funnctions', () => {

    it('01) This function can add two numbers.', function(){
        let result = sum(1, 3);
        result.should.be.equal(4);
    });
      
});