# JS-Training
## Javascript Functions

### Notes:
- The tests are in the file "js/tests.js". You do not need to change any code in the test file!
- The tests need the functions in the file "js/chapter-xx.js" to be implemented. 

    
